# Feedback Summary

This file summarizes the CAPCHAIN Google Form responses.

## Overall Summary

- Total responses: 50
- Response sheet: [`feedback.csv`](feedback.csv)
- Overall satisfaction:
  - Completely satisfied: 24
  - Satisfied: 14
  - Neutral: 10
  - Somewhat dissatisfied: 2
- Respondent roles:
  - Capstone Student: 27
  - Faculty Mentor: 12
  - Capstone Coordinator: 11
- Prior blockchain or cryptocurrency experience:
  - None: 23
  - Some general knowledge: 20
  - Experienced: 7

## Main Positive Points

- Users valued blockchain-based immutable records for academic integrity.
- The consent-based mentor assignment feature was seen as useful for coordination.
- COI detection was highlighted as a strong feature for fair evaluations.
- Clear rubric display and transparent grading rules were repeatedly mentioned.

## Main Improvement Suggestions

- Add more tutorial videos or onboarding support.
- Improve integration with email or existing academic tools.
- Make error messages clearer.
- Improve system response speed.

## Action Items

- Review the full response sheet before publishing publicly.
- Remove or anonymize private data before committing if any names or email IDs are present.
- Update this summary after any new responses are added.
